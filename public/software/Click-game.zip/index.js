
const sout = console.log.bind()
function r(a){return Math.random() * a;}

const urlVars = new URLSearchParams(window.location.search);

urlVars.append("bN", 10) // button Count
urlVars.append("ss" , 2) // Scaling Speed

if(!new URLSearchParams(window.location.search).has("bN"))
    document.location.search = urlVars.toString()

for(let i = 1; i <= parseInt(urlVars.get("bN")); i += parseInt(urlVars.get("ss"))){

    button = document.createElement("button");
    button.innerText = "click me"
    button.style.position = "relative"
    button.style.scale = i;
    button.style.borderColor = `rgb(${r(255)}, ${r(255)}, ${r(255)})` 
    document.body.appendChild(button);

    button.onclick = function(e){
        // let ding = new Audio("sfx.wav"); // https://mixkit.co/free-sound-effects/ding/ 
        let ding = new Audio("bamboo.mp3"); // https://www.myinstants.com/instant/bamboo-hit-18672/
        
        e.target.style.left = (Math.random() + 0.1) * window.innerWidth * 0.8 + "px";
        e.target.style.top  = (Math.random() + 0.1) * window.innerHeight * 0.8 + "px";
    
        ding.play()
    
    }
}



